                                                              -- ============================================================================
-- BLUETORN CRM — PRODUCTION MYSQL SCHEMA (TARGET: HOSTINGER MYSQL)
-- Engine: InnoDB, Charset: utf8mb4 / utf8mb4_unicode_ci
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `bluetorn_crm` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `bluetorn_crm`;

-- ----------------------------------------------------------------------------
-- 1. WORKSPACES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `workspaces` (
  `id` VARCHAR(36) NOT NULL,
  `code` VARCHAR(64) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `legal_name` VARCHAR(255) DEFAULT NULL,
  `industry` VARCHAR(128) NOT NULL DEFAULT 'Real Estate',
  `plan` VARCHAR(64) NOT NULL DEFAULT 'Starter',
  `status` ENUM('active','trial','suspended','inactive') NOT NULL DEFAULT 'trial',
  `currency` VARCHAR(10) NOT NULL DEFAULT 'INR',
  `timezone` VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',
  `date_format` VARCHAR(32) NOT NULL DEFAULT 'DD/MM/YYYY',
  `time_format` VARCHAR(16) NOT NULL DEFAULT '12h',
  `logo_url` TEXT DEFAULT NULL,
  `primary_color` VARCHAR(32) DEFAULT NULL,
  `contact_email` VARCHAR(255) DEFAULT NULL,
  `contact_phone` VARCHAR(64) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `gstin` VARCHAR(32) DEFAULT NULL,
  `pan` VARCHAR(32) DEFAULT NULL,
  `state` VARCHAR(64) DEFAULT NULL,
  `state_code` VARCHAR(8) DEFAULT NULL,
  `website` VARCHAR(255) DEFAULT NULL,
  `bank_name` VARCHAR(128) DEFAULT NULL,
  `bank_account_no` VARCHAR(64) DEFAULT NULL,
  `bank_account_name` VARCHAR(128) DEFAULT NULL,
  `bank_ifsc` VARCHAR(32) DEFAULT NULL,
  `invoice_prefix` VARCHAR(32) NOT NULL DEFAULT 'INV',
  `default_payment_terms_days` INT NOT NULL DEFAULT 14,
  `default_invoice_notes` TEXT DEFAULT NULL,
  `default_invoice_terms` TEXT DEFAULT NULL,
  `seat_limit` INT NOT NULL DEFAULT 10,
  `chat_retention_days` INT NOT NULL DEFAULT 15,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_workspaces_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. PROFILES (USERS)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `profiles` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) DEFAULT NULL,
  `user_code` VARCHAR(64) NOT NULL,
  `full_name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `phone` VARCHAR(64) DEFAULT NULL,
  `whatsapp_phone` VARCHAR(64) DEFAULT NULL,
  `job_title` VARCHAR(128) DEFAULT NULL,
  `avatar_url` TEXT DEFAULT NULL,
  `password_hash` VARCHAR(255) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `last_login_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_profiles_ws_user_code` (`workspace_id`, `user_code`),
  CONSTRAINT `fk_profiles_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. USER ROLES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` VARCHAR(36) NOT NULL,
  `user_id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) DEFAULT NULL,
  `role` ENUM('super_admin','owner','manager','employee') NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_role` (`user_id`, `workspace_id`, `role`),
  CONSTRAINT `fk_roles_user` FOREIGN KEY (`user_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_roles_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3b. USER PERMISSIONS (GRANULAR RBAC)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_permissions` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `user_id` VARCHAR(36) NOT NULL,
  `permission` VARCHAR(64) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_permission` (`workspace_id`, `user_id`, `permission`),
  KEY `idx_user_perm_lookup` (`workspace_id`, `user_id`),
  CONSTRAINT `fk_user_permissions_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_permissions_user` FOREIGN KEY (`user_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. CUSTOMERS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(64) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `type` VARCHAR(64) NOT NULL DEFAULT 'Buyer',
  `status` VARCHAR(64) NOT NULL DEFAULT 'Prospect',
  `city` VARCHAR(128) DEFAULT NULL,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'INR',
  `value` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `tags` JSON DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `assigned_to` VARCHAR(36) DEFAULT NULL,
  `assigned_at` DATETIME DEFAULT NULL,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_customers_ws` (`workspace_id`),
  KEY `idx_customers_assigned` (`assigned_to`),
  CONSTRAINT `fk_customers_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_customers_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `profiles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. PROPERTIES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `properties` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `location` VARCHAR(255) DEFAULT NULL,
  `type` VARCHAR(64) NOT NULL DEFAULT 'Apartment',
  `status` VARCHAR(64) NOT NULL DEFAULT 'Available',
  `price` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'INR',
  `bedrooms` INT DEFAULT NULL,
  `area_sqft` INT DEFAULT NULL,
  `image_url` TEXT DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `assigned_to` VARCHAR(36) DEFAULT NULL,
  `assigned_at` DATETIME DEFAULT NULL,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_properties_ws` (`workspace_id`),
  KEY `idx_properties_assigned` (`assigned_to`),
  CONSTRAINT `fk_properties_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_properties_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `profiles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5b. LEAD OPTIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `lead_options` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `type` ENUM('source', 'location', 'purpose', 'possession_timeline', 'transaction_timeline', 'phase') NOT NULL,
  `name` VARCHAR(128) NOT NULL,
  `stable_key` VARCHAR(64) DEFAULT NULL,
  `is_system` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `updated_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_lead_options_ws_type_name` (`workspace_id`, `type`, `name`),
  KEY `idx_lead_options_ws_type_active` (`workspace_id`, `type`, `is_active`, `sort_order`),
  KEY `idx_lead_options_ws_stable_key` (`workspace_id`, `type`, `stable_key`),
  CONSTRAINT `fk_lead_options_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. LEADS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `leads` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(64) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `source` VARCHAR(64) NOT NULL DEFAULT 'Manual Entry',
  `source_option_id` VARCHAR(36) DEFAULT NULL,
  `campaign` VARCHAR(128) DEFAULT NULL,
  `external_id` VARCHAR(128) DEFAULT NULL,
  `status` VARCHAR(64) NOT NULL DEFAULT 'New',
  `requirement` TEXT DEFAULT NULL,
  `location_option_id` VARCHAR(36) DEFAULT NULL,
  `purpose_option_id` VARCHAR(36) DEFAULT NULL,
  `possession_timeline_option_id` VARCHAR(36) DEFAULT NULL,
  `transaction_timeline_option_id` VARCHAR(36) DEFAULT NULL,
  `phase_option_id` VARCHAR(36) DEFAULT NULL,
  `budget` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'INR',
  `score` INT NOT NULL DEFAULT 50,
  `next_follow_up` DATETIME DEFAULT NULL,
  `received_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `assigned_to` VARCHAR(36) DEFAULT NULL,
  `assigned_at` DATETIME DEFAULT NULL,
  `property_id` VARCHAR(36) DEFAULT NULL,
  `customer_id` VARCHAR(36) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `converted_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_leads_ws` (`workspace_id`),
  KEY `idx_leads_assigned` (`assigned_to`),
  KEY `idx_leads_source_opt` (`source_option_id`),
  KEY `idx_leads_location_opt` (`location_option_id`),
  KEY `idx_leads_purpose_opt` (`purpose_option_id`),
  KEY `idx_leads_possession_opt` (`possession_timeline_option_id`),
  KEY `idx_leads_transaction_opt` (`transaction_timeline_option_id`),
  KEY `idx_leads_phase_opt` (`phase_option_id`),
  CONSTRAINT `fk_leads_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_leads_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `profiles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_source_opt` FOREIGN KEY (`source_option_id`) REFERENCES `lead_options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_location_opt` FOREIGN KEY (`location_option_id`) REFERENCES `lead_options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_purpose_opt` FOREIGN KEY (`purpose_option_id`) REFERENCES `lead_options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_possession_opt` FOREIGN KEY (`possession_timeline_option_id`) REFERENCES `lead_options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_transaction_opt` FOREIGN KEY (`transaction_timeline_option_id`) REFERENCES `lead_options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leads_phase_opt` FOREIGN KEY (`phase_option_id`) REFERENCES `lead_options` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. LEAD ACTIVITIES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `lead_activities` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `lead_id` VARCHAR(36) NOT NULL,
  `type` VARCHAR(64) NOT NULL,
  `note` TEXT DEFAULT NULL,
  `actor_id` VARCHAR(36) DEFAULT NULL,
  `actor_label` VARCHAR(128) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lead_act_lead` (`lead_id`),
  CONSTRAINT `fk_activities_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. TASKS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `due_at` DATETIME DEFAULT NULL,
  `priority` VARCHAR(32) NOT NULL DEFAULT 'Medium',
  `status` VARCHAR(32) NOT NULL DEFAULT 'Open',
  `assigned_to` VARCHAR(36) DEFAULT NULL,
  `assigned_at` DATETIME DEFAULT NULL,
  `lead_id` VARCHAR(36) DEFAULT NULL,
  `customer_id` VARCHAR(36) DEFAULT NULL,
  `property_id` VARCHAR(36) DEFAULT NULL,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_ws` (`workspace_id`),
  KEY `idx_tasks_assigned` (`assigned_to`),
  CONSTRAINT `fk_tasks_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tasks_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `profiles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. CALENDAR EVENTS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `calendar_events` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `type` VARCHAR(64) NOT NULL DEFAULT 'Meeting',
  `status` VARCHAR(32) NOT NULL DEFAULT 'Scheduled',
  `start_at` DATETIME NOT NULL,
  `end_at` DATETIME DEFAULT NULL,
  `location` TEXT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `lead_id` VARCHAR(36) DEFAULT NULL,
  `customer_id` VARCHAR(36) DEFAULT NULL,
  `property_id` VARCHAR(36) DEFAULT NULL,
  `assigned_to` VARCHAR(36) DEFAULT NULL,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_events_ws` (`workspace_id`),
  CONSTRAINT `fk_events_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 10. INVOICES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `invoice_number` VARCHAR(64) NOT NULL,
  `financial_year` VARCHAR(16) DEFAULT NULL,
  `invoice_type` VARCHAR(32) NOT NULL DEFAULT 'Tax Invoice',
  `customer_id` VARCHAR(36) DEFAULT NULL,
  `lead_id` VARCHAR(36) DEFAULT NULL,
  `property_id` VARCHAR(36) DEFAULT NULL,
  `assigned_to` VARCHAR(36) DEFAULT NULL,
  `updated_by` VARCHAR(36) DEFAULT NULL,
  `status` VARCHAR(32) NOT NULL DEFAULT 'Draft',
  `issue_date` DATE NOT NULL,
  `due_date` DATE DEFAULT NULL,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'INR',
  `tax_rate` DECIMAL(6,3) NOT NULL DEFAULT 0.000,
  `subtotal` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `discount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `taxable_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `cgst` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `sgst` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `igst` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `cess` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `tax_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `place_of_supply` VARCHAR(64) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `terms` TEXT DEFAULT NULL,
  `cancellation_reason` TEXT DEFAULT NULL,
  `cancelled_at` DATETIME DEFAULT NULL,
  `cancelled_by` VARCHAR(36) DEFAULT NULL,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_invoices_ws_number` (`workspace_id`, `invoice_number`),
  KEY `idx_invoices_ws_status` (`workspace_id`, `status`),
  KEY `idx_invoices_customer` (`customer_id`),
  KEY `idx_invoices_assigned` (`assigned_to`),
  CONSTRAINT `fk_invoices_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invoices_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `profiles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `profiles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 11. INVOICE ITEMS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `invoice_items` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `invoice_id` VARCHAR(36) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `hsn_sac` VARCHAR(32) DEFAULT NULL,
  `quantity` DECIMAL(12,2) NOT NULL DEFAULT 1.00,
  `unit` VARCHAR(32) NOT NULL DEFAULT 'Units',
  `rate` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `unit_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `discount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `tax_rate` DECIMAL(6,3) NOT NULL DEFAULT 0.000,
  `tax_type` VARCHAR(32) NOT NULL DEFAULT 'GST',
  `tax_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `line_total` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `position` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_items_invoice` (`invoice_id`),
  CONSTRAINT `fk_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 12. PAYMENTS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payments` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `invoice_id` VARCHAR(36) DEFAULT NULL,
  `customer_id` VARCHAR(36) DEFAULT NULL,
  `assigned_to` VARCHAR(36) DEFAULT NULL,
  `updated_by` VARCHAR(36) DEFAULT NULL,
  `amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'INR',
  `method` VARCHAR(64) NOT NULL DEFAULT 'Bank Transfer',
  `status` VARCHAR(32) NOT NULL DEFAULT 'Received',
  `paid_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reference` VARCHAR(128) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `reversal_reason` TEXT DEFAULT NULL,
  `reversed_at` DATETIME DEFAULT NULL,
  `reversed_by` VARCHAR(36) DEFAULT NULL,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_payments_ws` (`workspace_id`),
  KEY `idx_payments_invoice` (`invoice_id`),
  KEY `idx_payments_assigned` (`assigned_to`),
  CONSTRAINT `fk_payments_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payments_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payments_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `profiles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payments_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `profiles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 13. PLANS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `plans` (
  `id` VARCHAR(36) NOT NULL,
  `code` VARCHAR(64) NOT NULL,
  `name` VARCHAR(128) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `price_monthly` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'INR',
  `seat_limit` INT NOT NULL DEFAULT 10,
  `features` JSON DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_plans_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 14. PROMOTIONAL MEDIA
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `promo_media` (
  `id` VARCHAR(36) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `body` TEXT DEFAULT NULL,
  `image_url` TEXT DEFAULT NULL,
  `target` VARCHAR(128) NOT NULL DEFAULT 'All workspaces',
  `priority` INT NOT NULL DEFAULT 1,
  `start_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_at` DATETIME DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 15. PLATFORM SETTINGS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `platform_settings` (
  `key` VARCHAR(128) NOT NULL,
  `value` JSON NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` VARCHAR(36) DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 16. AUDIT LOGS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) DEFAULT NULL,
  `actor_id` VARCHAR(36) DEFAULT NULL,
  `actor_label` VARCHAR(128) DEFAULT NULL,
  `action` VARCHAR(128) NOT NULL,
  `entity_type` VARCHAR(64) DEFAULT NULL,
  `entity_id` VARCHAR(64) DEFAULT NULL,
  `metadata` JSON DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_ws_created` (`workspace_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 17. NOTIFICATIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `user_id` VARCHAR(36) NOT NULL,
  `type` VARCHAR(64) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT DEFAULT NULL,
  `entity_type` VARCHAR(64) DEFAULT NULL,
  `entity_id` VARCHAR(64) DEFAULT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_by` VARCHAR(36) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`, `is_read`),
  KEY `idx_notifications_ws` (`workspace_id`),
  CONSTRAINT `fk_notifications_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 18. CHAT CONVERSATIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `chat_conversations` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `type` VARCHAR(20) NOT NULL DEFAULT 'direct', -- 'direct' | 'group'
  `title` VARCHAR(120) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `owner_id` VARCHAR(36) DEFAULT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active' | 'archived'
  `user1_id` VARCHAR(36) DEFAULT NULL,
  `user2_id` VARCHAR(36) DEFAULT NULL,
  `last_message_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_chat_conversation_pair` (`workspace_id`, `user1_id`, `user2_id`),
  KEY `idx_chat_conv_ws` (`workspace_id`),
  KEY `idx_chat_conv_ws_type_status` (`workspace_id`, `type`, `status`),
  KEY `idx_chat_conv_owner` (`owner_id`),
  KEY `idx_chat_conv_u1` (`user1_id`),
  KEY `idx_chat_conv_u2` (`user2_id`),
  KEY `idx_chat_conv_last_msg` (`workspace_id`, `last_message_at`),
  CONSTRAINT `fk_chat_conv_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_chat_conv_owner` FOREIGN KEY (`owner_id`) REFERENCES `profiles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_chat_conv_u1` FOREIGN KEY (`user1_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_chat_conv_u2` FOREIGN KEY (`user2_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 19. CHAT CONVERSATION MEMBERS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `chat_conversation_members` (
  `id` VARCHAR(36) NOT NULL,
  `conversation_id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `user_id` VARCHAR(36) NOT NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'member', -- 'owner' | 'member'
  `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `left_at` DATETIME DEFAULT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active' | 'left' | 'removed'
  `last_read_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_conv_member` (`conversation_id`, `user_id`),
  KEY `idx_conv_members_user` (`user_id`, `status`),
  KEY `idx_conv_members_ws` (`workspace_id`),
  KEY `idx_conv_members_joined` (`conversation_id`, `joined_at`),
  CONSTRAINT `fk_conv_members_conv` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_conv_members_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_conv_members_user` FOREIGN KEY (`user_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 20. CHAT MESSAGES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` VARCHAR(36) NOT NULL,
  `workspace_id` VARCHAR(36) NOT NULL,
  `conversation_id` VARCHAR(36) NOT NULL,
  `sender_id` VARCHAR(36) NOT NULL,
  `receiver_id` VARCHAR(36) DEFAULT NULL,
  `body` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `read_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_chat_msg_ws` (`workspace_id`),
  KEY `idx_chat_msg_conv_created` (`conversation_id`, `created_at`),
  KEY `idx_chat_msg_receiver_read` (`workspace_id`, `receiver_id`, `is_read`),
  KEY `idx_chat_msg_expires` (`expires_at`),
  CONSTRAINT `fk_chat_msg_ws` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_chat_msg_conv` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_chat_msg_sender` FOREIGN KEY (`sender_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_chat_msg_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


