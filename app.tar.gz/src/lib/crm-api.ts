/**
 * BLUETORN CRM — client-safe data access layer.
 *
 * Forwards requests to TanStack Start server functions in crm.functions.ts.
 * Contains NO direct database imports (no mysql2, no db.ts).
 */
import type {
  Customer,
  Property,
  Lead,
  LeadOption,
  LeadOptionType,
  LeadActivity,
  Task,
  CalendarEvent,
  Invoice,
  InvoiceItem,
  Payment,
  Plan,
  PromoMedia,
  AuditLog,
  Notification,
  ChatConversation,
  ChatMessage,
  ChatConversationSummary,
  ChatParticipant,
  ChatConversationMember,
} from "./db-types";

import {
  listChatConversationsFn,
  getChatMessagesFn,
  sendChatMessageFn,
  markConversationReadFn,
  getChatUnreadCountFn,
  listAvailableChatUsersFn,
  getWorkspaceRetentionPolicyFn,
  updateWorkspaceRetentionPolicyFn,
  createChatGroupFn,
  getGroupMembersFn,
  addGroupMembersFn,
  removeGroupMemberFn,
  leaveChatGroupFn,
  renameChatGroupFn,
  archiveChatGroupFn,
  restoreChatGroupFn,
  deleteChatGroupFn,
  listArchivedChatGroupsFn,
} from "./chat.functions.ts";

import {
  listMembersFn,
  listCustomersFn,
  getCustomerFn,
  createCustomerFn,
  updateCustomerFn,
  deleteCustomerFn,
  listPropertiesFn,
  getPropertyFn,
  createPropertyFn,
  updatePropertyFn,
  deletePropertyFn,
  listLeadsFn,
  getLeadFn,
  createLeadFn,
  updateLeadFn,
  deleteLeadFn,
  listLeadOptionsFn,
  createLeadOptionFn,
  updateLeadOptionFn,
  setLeadOptionActiveFn,
  deleteLeadOptionFn,
  convertLeadToCustomerFn,
  listLeadActivityFn,
  logLeadActivityFn,
  deleteLeadActivityFn,
  listTasksFn,
  createTaskFn,
  updateTaskFn,
  deleteTaskFn,
  listEventsFn,
  createEventFn,
  updateEventFn,
  deleteEventFn,
  listInvoicesFn,
  getInvoiceFn,
  nextInvoiceNumberFn,
  saveInvoiceFn,
  updateInvoiceStatusFn,
  cancelInvoiceFn,
  deleteInvoiceFn,
  listPaymentsFn,
  createPaymentFn,
  updatePaymentFn,
  reversePaymentFn,
  deletePaymentFn,
  reconcileInvoiceFn,
  getFinanceReportsFn,
  listPlansFn,
  createPlanFn,
  updatePlanFn,
  deletePlanFn,
  listPromoMediaFn,
  createPromoMediaFn,
  updatePromoMediaFn,
  deletePromoMediaFn,
  getPlatformSettingsFn,
  savePlatformSettingsFn,
  listAuditLogsFn,
  listWorkspaceAuditLogsFn,
  recordAuditFn,
  runWorkspaceCleanupFn,
  getWorkspaceStorageUsageFn,
  getDashboardDataFn,
  searchCrmFn,
  listNotificationsFn,
  unreadNotificationCountFn,
  markNotificationReadFn,
  markAllNotificationsReadFn,
  deleteNotificationFn,
  clearAllNotificationsFn,
  type Member,
  type PlatformSettings,
  type DashboardData,
  type SearchResult,
  type FinanceReportsData,
  type AuditLogItem,
  type AuditLogListResponse,
} from "./crm.functions";

import type { CentralizedCleanupSummary, WorkspaceStorageBreakdown } from "./retention-cleanup";

import { invoiceTotals, computeInvoiceTotals, type InvoiceLineInput } from "./invoice-calculations";

export type {
  Customer,
  Property,
  Lead,
  LeadOption,
  LeadOptionType,
  LeadActivity,
  Task,
  CalendarEvent,
  Invoice,
  InvoiceItem,
  Payment,
  Plan,
  PromoMedia,
  Member,
  InvoiceLineInput,
  PlatformSettings,
  DashboardData,
  SearchResult,
  Notification,
  FinanceReportsData,
  AuditLogItem,
  AuditLogListResponse,
  CentralizedCleanupSummary,
  WorkspaceStorageBreakdown,
};

export type Activity = DashboardData["recentActivities"][number];

export { invoiceTotals, computeInvoiceTotals };

export const leadStatuses = [
  "New",
  "Contacted",
  "Interested",
  "Visit / Meeting",
  "Negotiation",
  "Won",
  "Lost",
] as const;
export type LeadStatus = (typeof leadStatuses)[number];

export const leadSources = [
  "Website",
  "WhatsApp",
  "Facebook",
  "Instagram",
  "LinkedIn",
  "Google Ads",
  "Meta Ads",
  "Referral",
  "Advertisement",
  "Landing Page",
  "Manual Entry",
  "API",
] as const;

export const customerTypes = ["Buyer", "Seller", "Investor", "Tenant"] as const;
export const customerStatuses = ["Prospect", "Active", "Archived"] as const;
export const propertyTypes = [
  "Apartment",
  "Villa",
  "Plot",
  "Commercial",
  "Office",
  "Warehouse",
] as const;
export const propertyStatuses = ["Available", "Reserved", "Booked", "Sold", "Inactive"] as const;
export const taskPriorities = ["Low", "Medium", "High"] as const;
export const taskStatuses = ["Open", "In Progress", "Completed", "Cancelled"] as const;
export const eventTypes = ["Meeting", "Site Visit", "Call", "Follow-up", "Other"] as const;
export const eventStatuses = ["Scheduled", "Completed", "Cancelled", "No Show"] as const;
export const invoiceStatuses = [
  "Draft",
  "Sent",
  "Partially Paid",
  "Paid",
  "Overdue",
  "Cancelled",
] as const;
export const paymentMethods = ["Bank Transfer", "UPI", "Cash", "Cheque", "Card", "Other"] as const;
export const paymentStatuses = ["Received", "Pending", "Failed", "Refunded"] as const;

/* --------------------------------- helpers -------------------------------- */

export const qk = {
  dashboard: (ws: string, userId?: string) => ["dashboard", ws, userId || ""] as const,
  search: (ws: string, q: string) => ["search", ws, q] as const,
  customers: (ws: string) => ["customers", ws] as const,
  customer: (id: string) => ["customer", id] as const,
  properties: (ws: string) => ["properties", ws] as const,
  property: (id: string) => ["property", id] as const,
  leads: (ws: string) => ["leads", ws] as const,
  lead: (id: string) => ["lead", id] as const,
  leadOptions: (ws: string, type?: string) => ["lead-options", ws, type || "all"] as const,
  leadActivity: (id: string) => ["lead-activity", id] as const,
  tasks: (ws: string) => ["tasks", ws] as const,
  events: (ws: string) => ["events", ws] as const,
  invoices: (ws: string) => ["invoices", ws] as const,
  invoice: (id: string) => ["invoice", id] as const,
  payments: (ws: string) => ["payments", ws] as const,
  members: (ws: string) => ["members", ws] as const,
  plans: () => ["plans"] as const,
  promos: () => ["promos"] as const,
  platformSettings: () => ["platform-settings"] as const,
  notifications: () => ["notifications"] as const,
  notificationCount: () => ["notification-count"] as const,
  chatConversations: () => ["chat", "conversations"] as const,
  chatMessages: (conversationId: string) => ["chat", "messages", conversationId] as const,
  chatUnreadCount: () => ["chat", "unread-count"] as const,
  chatAvailableUsers: () => ["chat", "available-users"] as const,
  chatRetentionPolicy: (workspaceId?: string) =>
    ["chat", "retention-policy", workspaceId || ""] as const,
  chatGroupMembers: (conversationId: string) => ["chat", "group-members", conversationId] as const,
  chatArchivedGroups: () => ["chat", "archived-groups"] as const,
};

/* -------------------------------- members --------------------------------- */

export async function listMembers(workspaceId: string): Promise<Member[]> {
  return listMembersFn({ data: { workspaceId } });
}

/* -------------------------------- customers ------------------------------- */

export async function listCustomers(workspaceId: string): Promise<Customer[]> {
  return listCustomersFn({ data: { workspaceId } });
}

export async function getCustomer(id: string): Promise<Customer | null> {
  return getCustomerFn({ data: { id } });
}

export async function createCustomer(
  input: Partial<Customer> & { workspace_id: string; name: string },
): Promise<Customer> {
  return createCustomerFn({ data: input });
}

export async function updateCustomer(id: string, patch: Partial<Customer>): Promise<Customer> {
  return updateCustomerFn({ data: { id, patch } });
}

export async function deleteCustomer(id: string): Promise<void> {
  await deleteCustomerFn({ data: { id } });
}

/* -------------------------------- properties ------------------------------ */

export async function listProperties(workspaceId: string): Promise<Property[]> {
  return listPropertiesFn({ data: { workspaceId } });
}

export async function getProperty(id: string): Promise<Property | null> {
  return getPropertyFn({ data: { id } });
}

export async function createProperty(
  input: Partial<Property> & { workspace_id: string; name: string },
): Promise<Property> {
  return createPropertyFn({ data: input });
}

export async function updateProperty(id: string, patch: Partial<Property>): Promise<Property> {
  return updatePropertyFn({ data: { id, patch } });
}

export async function deleteProperty(id: string): Promise<void> {
  await deletePropertyFn({ data: { id } });
}

/* ----------------------------------- leads -------------------------------- */

export async function listLeads(workspaceId: string): Promise<Lead[]> {
  return listLeadsFn({ data: { workspaceId } });
}

export async function getLead(id: string): Promise<Lead | null> {
  return getLeadFn({ data: { id } });
}

export async function createLead(
  input: Partial<Lead> & { workspace_id: string; name: string },
): Promise<Lead> {
  return createLeadFn({ data: input });
}

export async function updateLead(id: string, patch: Partial<Lead>): Promise<Lead> {
  return updateLeadFn({ data: { id, patch } });
}

export async function deleteLead(id: string): Promise<void> {
  await deleteLeadFn({ data: { id } });
}

/* -------------------------------- lead options ----------------------------- */

export async function listLeadOptions(
  workspaceId?: string,
  type?: LeadOptionType,
  includeInactive?: boolean,
): Promise<LeadOption[]> {
  const data: {
    workspaceId?: string | undefined;
    type?: LeadOptionType | undefined;
    includeInactive?: boolean | undefined;
  } = {
    workspaceId,
    type,
    includeInactive,
  };
  return listLeadOptionsFn({ data });
}

export async function createLeadOption(
  workspaceId: string | undefined,
  type: LeadOptionType,
  name: string,
): Promise<LeadOption> {
  const data: { workspaceId?: string | undefined; type: LeadOptionType; name: string } = {
    workspaceId,
    type,
    name,
  };
  return createLeadOptionFn({ data });
}

export async function updateLeadOption(
  id: string,
  patch: { name?: string; sort_order?: number },
): Promise<LeadOption> {
  return updateLeadOptionFn({ data: { id, ...patch } });
}

export async function setLeadOptionActive(id: string, isActive: boolean): Promise<LeadOption> {
  return setLeadOptionActiveFn({ data: { id, isActive } });
}

export async function deleteLeadOption(id: string): Promise<void> {
  await deleteLeadOptionFn({ data: { id } });
}

export async function convertLeadToCustomer(
  leadId: string,
): Promise<{ customer: Customer; alreadyConverted: boolean; isNew: boolean }> {
  return convertLeadToCustomerFn({ data: { leadId } });
}

export async function listLeadActivity(leadId: string): Promise<LeadActivity[]> {
  return listLeadActivityFn({ data: { leadId } });
}

export async function logLeadActivity(
  input: Partial<LeadActivity> & { workspace_id: string; lead_id: string; type: string },
): Promise<LeadActivity> {
  return logLeadActivityFn({ data: input });
}

export async function deleteLeadActivity(id: string): Promise<void> {
  await deleteLeadActivityFn({ data: { id } });
}

/* ----------------------------------- tasks -------------------------------- */

export async function listTasks(workspaceId: string): Promise<Task[]> {
  return listTasksFn({ data: { workspaceId } });
}

export async function createTask(
  input: Partial<Task> & { workspace_id: string; title: string },
): Promise<Task> {
  return createTaskFn({ data: input });
}

export async function updateTask(id: string, patch: Partial<Task>): Promise<Task> {
  return updateTaskFn({ data: { id, patch } });
}

export async function deleteTask(id: string): Promise<void> {
  await deleteTaskFn({ data: { id } });
}

/* -------------------------------- calendar -------------------------------- */

export async function listEvents(workspaceId: string): Promise<CalendarEvent[]> {
  return listEventsFn({ data: { workspaceId } });
}

export async function createEvent(
  input: Partial<CalendarEvent> & { workspace_id: string; title: string; start_at: string },
): Promise<CalendarEvent> {
  return createEventFn({ data: input });
}

export async function updateEvent(
  id: string,
  patch: Partial<CalendarEvent>,
): Promise<CalendarEvent> {
  return updateEventFn({ data: { id, patch } });
}

export async function deleteEvent(id: string): Promise<void> {
  await deleteEventFn({ data: { id } });
}

/* --------------------------------- finance -------------------------------- */

export async function listInvoices(workspaceId: string): Promise<Invoice[]> {
  return listInvoicesFn({ data: { workspaceId } });
}

export async function getInvoice(id: string): Promise<{
  invoice: Invoice;
  items: InvoiceItem[];
  payments: Payment[];
  activities?: any[];
} | null> {
  return getInvoiceFn({ data: { id } });
}

export async function nextInvoiceNumber(
  workspaceId: string,
): Promise<{ invoiceNumber: string; prefix: string; financialYear: string }> {
  return nextInvoiceNumberFn({ data: { workspaceId } });
}

export async function saveInvoice(params: {
  id?: string;
  workspaceId: string;
  invoice: {
    invoice_number: string;
    financial_year?: string | null;
    invoice_type?: string;
    customer_id?: string | null;
    lead_id?: string | null;
    property_id?: string | null;
    assigned_to?: string | null;
    status?: string;
    issue_date: string;
    due_date?: string | null;
    currency?: string;
    tax_rate?: number;
    place_of_supply?: string | null;
    notes?: string | null;
    terms?: string | null;
  };
  lines: InvoiceLineInput[];
}): Promise<Invoice> {
  return saveInvoiceFn({ data: params });
}

export async function updateInvoiceStatus(id: string, status: string): Promise<Invoice> {
  return updateInvoiceStatusFn({ data: { id, status } });
}

export async function cancelInvoice(id: string, reason: string): Promise<Invoice> {
  return cancelInvoiceFn({ data: { id, reason } });
}

export async function deleteInvoice(id: string): Promise<void> {
  await deleteInvoiceFn({ data: { id } });
}

export async function listPayments(workspaceId: string): Promise<Payment[]> {
  return listPaymentsFn({ data: { workspaceId } });
}

export async function createPayment(input: {
  workspace_id: string;
  invoice_id?: string | null;
  customer_id?: string | null;
  assigned_to?: string | null;
  amount: number;
  currency?: string;
  method: string;
  status?: string;
  paid_at?: string;
  reference?: string | null;
  notes?: string | null;
}): Promise<Payment> {
  return createPaymentFn({ data: input });
}

export async function updatePayment(id: string, patch: Partial<Payment>): Promise<Payment> {
  return updatePaymentFn({ data: { id, patch } });
}

export async function reversePayment(id: string, reason: string): Promise<Payment> {
  return reversePaymentFn({ data: { id, reason } });
}

export async function deletePayment(id: string): Promise<void> {
  await deletePaymentFn({ data: { id } });
}

export async function getFinanceReports(workspaceId: string): Promise<FinanceReportsData> {
  return getFinanceReportsFn({ data: { workspaceId } });
}

export async function reconcileInvoice(invoiceId: string): Promise<void> {
  await reconcileInvoiceFn({ data: { invoiceId } });
}

export function paidAmount(payments: Payment[]): number {
  return payments.filter((p) => p.status === "Received").reduce((s, p) => s + Number(p.amount), 0);
}

/* ----------------------------- platform config ---------------------------- */

export async function listPlans(): Promise<Plan[]> {
  return listPlansFn();
}

export async function createPlan(
  input: Partial<Plan> & { code: string; name: string },
): Promise<Plan> {
  return createPlanFn({ data: input });
}

export async function updatePlan(id: string, patch: Partial<Plan>): Promise<Plan> {
  return updatePlanFn({ data: { id, patch } });
}

export async function deletePlan(id: string): Promise<void> {
  await deletePlanFn({ data: { id } });
}

export async function listPromoMedia(): Promise<PromoMedia[]> {
  return listPromoMediaFn();
}

export async function createPromoMedia(
  input: Partial<PromoMedia> & { title: string },
): Promise<PromoMedia> {
  return createPromoMediaFn({ data: input });
}

export async function updatePromoMedia(
  id: string,
  patch: Partial<PromoMedia>,
): Promise<PromoMedia> {
  return updatePromoMediaFn({ data: { id, patch } });
}

export async function deletePromoMedia(id: string): Promise<void> {
  await deletePromoMediaFn({ data: { id } });
}

export async function getPlatformSettings(): Promise<PlatformSettings> {
  return getPlatformSettingsFn();
}

export async function savePlatformSettings(
  key: string,
  value: Record<string, unknown>,
): Promise<void> {
  await savePlatformSettingsFn({ data: { key, value } });
}

/* --------------------------------- audit ---------------------------------- */

export async function listAuditLogs(
  params: { workspaceId?: string; limit?: number } = {},
): Promise<AuditLog[]> {
  return listAuditLogsFn({ data: params });
}

export async function listWorkspaceAuditLogs(params?: {
  page?: number | undefined;
  pageSize?: number | undefined;
  search?: string | undefined;
  actorId?: string | undefined;
  module?: string | undefined;
  action?: string | undefined;
  status?: string | undefined;
  startDate?: string | undefined;
  endDate?: string | undefined;
}): Promise<AuditLogListResponse> {
  const clean: Record<string, any> = {};
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined) clean[k] = v;
    }
  }
  return listWorkspaceAuditLogsFn({ data: clean });
}

export async function recordAudit(input: Partial<AuditLog> & { action: string }): Promise<void> {
  await recordAuditFn({ data: input });
}

export async function runWorkspaceCleanup(): Promise<CentralizedCleanupSummary> {
  return runWorkspaceCleanupFn();
}

export async function getWorkspaceStorageUsage(): Promise<WorkspaceStorageBreakdown> {
  return getWorkspaceStorageUsageFn();
}

/* ------------------------------- dashboard -------------------------------- */

export async function getDashboardData(
  workspaceId: string,
  userRole?: string,
  userName?: string,
): Promise<DashboardData> {
  const payload: { workspaceId: string; userRole?: string; userName?: string } = { workspaceId };
  if (userRole) payload.userRole = userRole;
  if (userName) payload.userName = userName;
  return getDashboardDataFn({ data: payload });
}

/* --------------------------------- search ---------------------------------- */

export async function searchCrm(workspaceId: string, query: string): Promise<SearchResult> {
  return searchCrmFn({ data: { workspaceId, query } });
}

/* ------------------------------ notifications ------------------------------ */

export async function listNotifications(limit?: number): Promise<Notification[]> {
  return listNotificationsFn({ data: limit !== undefined ? { limit } : {} });
}

export async function getUnreadNotificationCount(): Promise<number> {
  const result = await unreadNotificationCountFn();
  return result.count;
}

export async function markNotificationRead(id: string): Promise<void> {
  await markNotificationReadFn({ data: { id } });
}

export async function markAllNotificationsRead(): Promise<void> {
  await markAllNotificationsReadFn();
}

export async function deleteNotification(id: string): Promise<void> {
  await deleteNotificationFn({ data: { id } });
}

export async function clearAllNotifications(): Promise<void> {
  await clearAllNotificationsFn();
}

/* --------------------------------- chat ----------------------------------- */

export async function listChatConversations(): Promise<ChatConversationSummary[]> {
  return listChatConversationsFn();
}

export async function getChatMessages(conversationId: string): Promise<{
  conversation: ChatConversation;
  participant?: ChatParticipant | null | undefined;
  messages: ChatMessage[];
  retentionDays: number;
  memberCount?: number | undefined;
  isOwner?: boolean | undefined;
}> {
  return getChatMessagesFn({ data: { conversationId } }) as any;
}

export async function sendChatMessage(input: {
  conversationId?: string | undefined;
  recipientId?: string | undefined;
  body: string;
}): Promise<{ message: ChatMessage; conversationId: string }> {
  return sendChatMessageFn({ data: input });
}

export async function markConversationRead(conversationId: string): Promise<void> {
  await markConversationReadFn({ data: { conversationId } });
}

export async function getChatUnreadCount(): Promise<number> {
  const result = await getChatUnreadCountFn();
  return result.unreadCount;
}

export async function listAvailableChatUsers(): Promise<ChatParticipant[]> {
  return listAvailableChatUsersFn();
}

export async function getWorkspaceRetentionPolicy(workspaceId?: string): Promise<{
  retentionDays: number;
  maxAllowed: number;
  allowedValues: number[];
}> {
  return getWorkspaceRetentionPolicyFn({ data: workspaceId ? { workspaceId } : {} });
}

export async function updateWorkspaceRetentionPolicy(input: {
  workspaceId: string;
  retentionDays: number;
}): Promise<{
  success: boolean;
  retentionDays: number;
  updatedMessages: number;
  deletedExpired: number;
}> {
  return updateWorkspaceRetentionPolicyFn({ data: input });
}

export async function createChatGroup(input: {
  title: string;
  description?: string | undefined;
  memberIds: string[];
}): Promise<{ conversationId: string; title: string }> {
  return createChatGroupFn({ data: input });
}

export async function getGroupMembers(conversationId: string): Promise<ChatConversationMember[]> {
  return getGroupMembersFn({ data: { conversationId } });
}

export async function addGroupMembers(input: {
  conversationId: string;
  userIds: string[];
}): Promise<{ success: boolean; addedCount: number }> {
  return addGroupMembersFn({ data: input });
}

export async function removeGroupMember(input: {
  conversationId: string;
  targetUserId: string;
}): Promise<{ success: boolean }> {
  return removeGroupMemberFn({ data: input });
}

export async function leaveChatGroup(conversationId: string): Promise<{ success: boolean }> {
  return leaveChatGroupFn({ data: { conversationId } });
}

export async function renameChatGroup(input: {
  conversationId: string;
  title: string;
  description?: string | undefined;
}): Promise<{ success: boolean; title: string }> {
  return renameChatGroupFn({ data: input });
}

export async function archiveChatGroup(conversationId: string): Promise<{ success: boolean }> {
  return archiveChatGroupFn({ data: { conversationId } });
}

export async function restoreChatGroup(conversationId: string): Promise<{ success: boolean }> {
  return restoreChatGroupFn({ data: { conversationId } });
}

export async function deleteChatGroup(conversationId: string): Promise<{ success: boolean }> {
  return deleteChatGroupFn({ data: { conversationId } });
}

export async function listArchivedChatGroups(): Promise<ChatConversationSummary[]> {
  return listArchivedChatGroupsFn();
}
